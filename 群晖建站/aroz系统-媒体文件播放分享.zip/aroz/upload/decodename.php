<?php
echo hex2bin($_GET["filename"])
?>