<?php
/**
 * 掌上客小程序商城模块微站定义
 * 
 * @author KAIMLEcms
 * @url 
 */
defined('IN_IA') or exit('Access Denied');
ini_set("display_errors", "OFF"); 
!defined('KAIMLE') && define('KAIMLE',IA_ROOT.'/addons/kaimle_browser');
!defined('CORE_WEB') && define('CORE_WEB',KAIMLE.'/core/web');
!defined('CORE_MOB') && define('CORE_MOB',KAIMLE.'/core/mob');
!defined('CORE_APP') && define('CORE_APP',KAIMLE.'/core/wxapp');
!defined('WEB') && define('WEB','../addons/kaimle_browser/template/web');
!defined('PUB') && define('PUB','../addons/kaimle_browser/template/public');
if (!function_exists('M')) {
	function M($name) {
		$model = new KAIMLExdswModel($name);
		return $model;
	} 
} 
require_once KAIMLE."/libs/model.class.php"; 
class kaimle_browserModuleSite extends WeModuleSite {
	 
	public function doWebHome(){
		global $_W,$_GPC;
		$model=M("home");
		$uniacid=intval($_W['uniacid']); 
		$func=$_GPC['act'];
		if(strlen($func)<1){
			$func="edit";
		} 
		if($func=="edit"){  
			$home=$model->where("uniacid=$uniacid")->get("*");
			include $this->template("web/home-edit");
		} 
		else if($func=="save"){
			$home=$model->where("uniacid=$uniacid")->get("*");
			$home1=array(
				"bar_color"=>trim($_POST['bar_color']),
				"url"=>urlencode($_POST['url']),
				"bar_bgcolor"=>trim($_POST['bar_bgcolor']),
				"share"=>trim($_POST['share']),

			);
			$hid=intval($home['id']);
			if($hid>0){ 
				$res=$model->where("uniacid=$uniacid")->save($home1);
				 message("保存成功",$this->createWebUrl("home"));	 
				 
			}else{
				 
				$home1['uniacid']=$uniacid;
				$model=M("home");
				$res=$model->add($home1);  
				if($res){
					message("保存成功",$this->createWebUrl("home"));
				}else{
					message("保存失败");
				}
				 
			}
		} 

	}
	 
}