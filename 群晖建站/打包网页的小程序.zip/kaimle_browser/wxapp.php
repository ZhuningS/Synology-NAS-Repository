<?php
/**
 * 掌上客小程序商城模块小程序接口定义
 *
 * @url 
 */
defined('IN_IA') or exit('Access Denied');
ini_set("display_errors", "OFF"); 
!defined('KAIMLE') && define('KAIMLE',IA_ROOT.'/addons/kaimle_browser');
!defined('CORE_APP') && define('CORE_APP',KAIMLE.'/core/web');
!defined('CORE_MOB') && define('CORE_MOB',KAIMLE.'/core/mob');
!defined('CORE_APP') && define('CORE_APP',KAIMLE.'/core/wxapp');
if (!function_exists('M')) {
	function M($name) {
		$model = new KAIMLExdswModel($name);
		return $model;
	} 
} 
require_once KAIMLE."/libs/model.class.php"; 
class kaimle_browserModuleWxapp extends WeModuleWxapp {
	 
	public function doPageHome() {
		global $_W;
	 	$uniacid=intval($_W['uniacid']);
		$model=M("home");
		$home=$model->where("uniacid=$uniacid")->get("*");
		$home['url']=urldecode($home['url']); 
		echo json_encode($home);
		 
	}
}