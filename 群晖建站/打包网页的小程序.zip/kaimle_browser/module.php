<?php
/**
 * 掌上客小程序商城模块定义
 *
 * @author KAIMLEcms
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class kaimle_browserModule extends WeModule {



}