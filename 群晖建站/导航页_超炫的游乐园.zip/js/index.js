//Disclaimer for FF users (I am one of them)

// For correct animation please view this SVG through webkit browsers. Firefox is known for issue with transform-origin property specifically in svg. Nothing works well until you'll include transform-box: fill-box; (works in FF only) in CSS AND enable svg-transform-box property in about:config file. Thanks, Mozilla