<?php
/**
 * 对文件 路径进行编码
 *
 * @param string $path
 */
function encodePath($path)
{
    $tmp_array = explode('/', $path);
    foreach ($tmp_array as $key => $value)
    {
        if ($value == '')           //删除空内容
            unset($tmp_array[$key]);
        $tmp_array[$key]=rawurlencode($value);
    }
    return implode("/", $tmp_array);
}

/**
 * 显示验证的输入窗口
 * @param string $user 用户名
 * @param string $pass 密码
 * @access public
 */

//2005-4-11
//显示当前目录下的文件
$_CONFIG["SiteName"]="DM-Server文件共享";        //网站名称
$_CONFIG["SiteUrl"]="https://www.dmnas.top";            //网站地址

?>
<html>
<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.dmnas.top/piwik/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', '3']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Piwik Code -->
<head><meta name="baidu-site-verification" content="mmvsYQE3uS" />
<title><?print($_CONFIG["SiteName"])." ".$_CONFIG["SiteUrl"];?></title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="shortcut icon" href="111.jpg" type="image/x-icon" />
<style type="text/css">
<!--
A:link {
     COLOR: #000000; FONT-FAMILY: 宋体; TEXT-DECORATION: none
}
A:active {
    COLOR: #000000; FONT-FAMILY: 宋体; TEXT-DECORATION: none
}
A:visited {
     COLOR: #000000; FONT-FAMILY: 宋体; TEXT-DECORATION: none
}
A:hover {
     COLOR: #999999; FONT-FAMILY: 宋体; TEXT-DECORATION: underline
}

BODY {
    WORD-BREAK: break-all; LINE-HEIGHT: 150%
}

-->
td{
	font-size:22px;
	padding:1px;
}
table{
	text-align:center;
}
b{
	font-size:20px;
}
h1{
	padding:0px;
	margin:0px;
}
div{
	padding:0;
	marging:0;
	float:left;
	font-size:20px;
}
.sp1{
	width:40%;
	
}
.sp2{
	width:20%;
	
}
.sp3{
	width:30%;
	
}
.sp4{
	width:5%;
	
}
 a.disabled {
            pointer-events: none;
            }
iframe{
	width:95%;
	height:22px;
	
}
a b{
	font-size:20px;
}
a:hover { color:#FFD306; }
</style>
</head>

<body bgcolor="	#FFFFFF" text="#000000" oncontextmenu=self.event.returnValue=false onselectstart="return false"
>
<center><font color=#000><?print("<h1>".$_CONFIG["SiteName"])."</h1>";?></font>
<br><a href=<?print($_CONFIG["SiteUrl"]);?>><?print($_CONFIG["SiteUrl"]);?></a>
</center>
<table border=1  width=98% align="center"  bordercolordark="#FFFFFF"  cellpadding="2" cellspacing="2">
<tr>
<?

$_DIR_PATH="./";
if(!empty($_GET["dir"]) && strlen($_GET["dir"])>3 && ".."!=substr($_GET["dir"], 0, 2))
{
    $prevRealpath=dirname($_GET["dir"]);    //得到上一层的目录
    if(substr($_GET["dir"], -1) != '/')
    {    $_GET["dir"] .= '/';
    }
    $_DIR_PATH=$_GET["dir"];

//    print($_DIR_PATH);
//    die();

    print("<td><b>当前目录路径：</b>[<b>".$_DIR_PATH."</b>]</td>");
    print("<td align=right>");
    print("　<a href='?dir='>");
    print("<b>返回根目录</b>");
    print("</a>");
    
    print("　<a href='?dir=".rawurlencode($prevRealpath)."' ");
    if($_DIR_PATH=='./sda3/server/'){echo" class='disabled '";}
	print("><b>返回上一层目录</b>");
    print("</a>　");
    print("</td>");

}
$numb=0;
if(empty($_DIR_PATH))
    $DIRObject=dir("./");
else
    $DIRObject=dir($_DIR_PATH);


?>
</tr></table>

<table border=1  width=98% align="center"  bordercolordark="#FFFFFF"  cellpadding="2" cellspacing="2">
<tr><td><b><div  class='sp4' >类型</div><div  class='sp1' >名称</div><div  class='sp2'  >占用空间</div><div class='sp3' >创建日期</div></b></td></tr>
<?

while($tmp_Str=$DIRObject->read())
{
    if($tmp_Str!="."&&$tmp_Str!="..")
    {
        $numb++;
        if(is_dir($DIRObject->path.$tmp_Str))        //是目录
        {
			if(strstr($tmp_Str,"scss") || strstr($tmp_Str,"@eaDir") || strstr($tmp_Str,"#recycle") || strstr($tmp_Str,"less") || strstr($tmp_Str,"js") || strstr($tmp_Str,"img") || strstr($tmp_Str,"iframe") || strstr($tmp_Str,"ico") || strstr($tmp_Str,"fonts") || strstr($tmp_Str,"pe") || strstr($tmp_Str,"css") || strstr($tmp_Str,"dm.music") || strstr($tmp_Str,"aria2") || strstr($tmp_Str,"lost+found") || strstr($tmp_Str,"loop0") || strstr($tmp_Str,"sda1") || strstr($tmp_Str,"sda2")  )    //不显示目录
                continue;
			print("<tr>");
            print("<td>");
			
			print("<a href='?dir=".encodePath($_DIR_PATH.$tmp_Str));
			print("'><b><div  class='sp4' >文件夹</div><div class='sp1' >".$tmp_Str."</b>");
            
			
			print("</div><div class='sp2' >");
			
            $neirong=$_DIR_PATH.$tmp_Str;
			$neirong= __DIR__.'/'.substr($neirong,strpos($str, './')+2,10000000000);
			//echo $neirong;
			$str= exec("du -sh {$neirong}");
			//echo exec("du -sh {$neirong}");
			echo substr($str,0,strpos($str, '/'));
			
			print("</div><div class='sp3' >");
			
			print ( strftime ( " %Y-%m-%d %H:%M:%S " , filemtime ( $_DIR_PATH . $tmp_Str )));
            print(" </div></b></a></td>");
			print("</tr>");
			
        }
        else    //其他显示的文件
        {
            if(strstr($tmp_Str,"HELP-US-OUT.txt") || strstr($tmp_Str,"wwweb.tar.gz") || strstr($tmp_Str,"timg.jpg") || strstr($tmp_Str,"timg.gif") || strstr($tmp_Str,"README.md") || strstr($tmp_Str,"favcion.ico") || strstr($tmp_Str,".php") || strstr($tmp_Str,"111.jpg") || strstr($tmp_Str,".asp") || strstr($tmp_Str,".html")  )    //不显示 .php .asp的文件
                continue;
				print("<tr>");
				print("<td>");
				print("<a target=_blank href='down.php?name=".$tmp_Str."&url=".encodePath($_DIR_PATH.$tmp_Str)."'><b><div  class='sp4' >文 件</div><div class='sp1' >");
            print($tmp_Str);    //$_DIR_PATH.
            print("</div><div class='sp2' >");
           
			$kbSize=round(filesize($_DIR_PATH.$tmp_Str)/1024,2);
            $mbSize=round($kbSize/1024,2);
            $gbSize=round($mbSize/1024,2);
            $tbSize=round($gbSize/1024,2);
            if($kbSize<1024)
                print("".$kbSize."  KB");
            if($mbSize>=1&$mbSize<1024)
                print("".$mbSize."  MB");
            if($gbSize>=1&$gbSize<1024)
                print("".$gbSize."  GB");
            if($tbSize>=1&$tbSize<1024)
                print("".$tbSize."  TB");
            
			print("</div><div class='sp3' >");
			
			print ( strftime ( " %Y-%m-%d %H:%M:%S " , filemtime ( $_DIR_PATH . $tmp_Str )));
			

	
            
			print("</div></b></a>");
            print(" </td>");
			print("</tr>");
        }

        //if($numb%5==0)
        //    print("</tr><tr>");
    }
}
$DIRObject->close();


?>
</table>
</body>
</html>
<script>
document.oncontextmenu = function(){
  return false;
}
document.onkeydown = function(){
  if (event.ctrlKey && window.event.keyCode==85){
    return false;
  }
}
document.body.oncopy = function (){
  return false;
}
//不建议连选中文本都不行
document.onselectstart = function(){
  return false;
}
</script>