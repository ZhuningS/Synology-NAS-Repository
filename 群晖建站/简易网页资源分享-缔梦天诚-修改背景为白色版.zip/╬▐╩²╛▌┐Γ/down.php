<?php
@ $url=$_GET['url'];
header("location:".$url);
?>